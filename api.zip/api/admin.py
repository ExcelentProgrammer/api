from django.contrib import admin
from .models import tgBotModel


admin.site.register(tgBotModel)